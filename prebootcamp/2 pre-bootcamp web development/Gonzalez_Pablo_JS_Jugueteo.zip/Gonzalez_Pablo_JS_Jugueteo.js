var alturaNiño = 52;
function muestraSiElNiñoPuedeSubirALaMontañaRusa(altura){
    if ( altura > 52){
        console.log("Subete chico");
    }else{
        console.log("Lo siento chico tal vez el proximo año")
    }
}
muestraSiElNiñoPuedeSubirALaMontañaRusa(alturaNiño);