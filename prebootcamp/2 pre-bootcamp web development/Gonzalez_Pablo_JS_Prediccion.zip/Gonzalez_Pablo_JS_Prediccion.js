function myBirthYearFunc(){
        console.log("Nací en " + 1980);
    }

// La salida sera Naci en 1980


function myBirthYearFunc(){
        console.log("Nací en " + 1980);
    }
// La salida sera Naci en 1980

function add(num1, num2){
        console.log("¡Sumando números!");
        console.log("num1 is: " + num1);
        console.log("num2 is: " + num2);
        var sum = num1 + num2;
        console.log(sum);
}
// La salida sera 
//¡Sumando números!
//num1 is: 10
//num2 is: 20
//30  
